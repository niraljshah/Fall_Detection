use example;


$e1 = new example::XMLChTest();
$e1->set("hello");
print $e1->get(),"\n";
print $e1->get_first(),"\n";

