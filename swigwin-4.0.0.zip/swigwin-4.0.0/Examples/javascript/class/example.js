module.exports = require("build/Release/example");
