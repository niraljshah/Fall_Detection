var example = require("example");

example.f();
example.f(1);
example.f(1, 2);
example.f("bla");
example.f(false);
example.f(11111111111);
example.f_double(1.0);
