/* File : example.c */

#include "example.h"
